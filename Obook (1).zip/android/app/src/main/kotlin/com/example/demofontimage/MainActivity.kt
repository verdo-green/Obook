package com.example.demofontimage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
