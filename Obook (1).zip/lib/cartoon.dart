import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class Cartoon {
  final String? name;
  final String? bookname;
  final String? imageUrl;
  final String? details;

  Cartoon({this.name, this.bookname, this.imageUrl, this.details});

  factory Cartoon.fromJson(Map<String, dynamic> json) {
    return Cartoon(
      name: json['name'],
      bookname: json['bookname'],
      imageUrl: json['image'],
      details: json['details'],
    );
  }
}

class CartoonListPage extends StatefulWidget {
  @override
  _CartoonListPageState createState() => _CartoonListPageState();
}

class _CartoonListPageState extends State<CartoonListPage> {
  List<Cartoon> cartoons = [];

  @override
  void initState() {
    super.initState();
    loadJsonData();
  }

  // Load JSON data from assets
  Future<void> loadJsonData() async {
    final String response = await rootBundle.loadString('assets/Cartoon.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      cartoons = data.map((item) => Cartoon.fromJson(item)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'การ์ตูน',
          style: GoogleFonts.itim(fontSize: 22, color: Color(0xff000000)),
        ),
      ),
      body: cartoons.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: cartoons.length,
              itemBuilder: (context, index) {
                final cartoon = cartoons[index];
                return Card(
                  color: Color(0xff1b1b1b),
                  elevation: 10,
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              CartoonDetailPage(cartoon: cartoon),
                        ),
                      );
                    },
                    leading: cartoon.imageUrl!.startsWith('http')
                        ? Image.network(cartoon.imageUrl!, width: 100)
                        : Image.asset(cartoon.imageUrl!, width: 100),
                    title: Text(
                      'ผู้เขียน : ${cartoon.name}',
                      style: GoogleFonts.itim(
                          fontSize: 15, color: Color(0xff5bffc4)),
                    ),
                    subtitle: Text(
                      cartoon.bookname ?? '',
                      style: GoogleFonts.itim(fontSize: 20, color: Colors.blue),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class CartoonDetailPage extends StatelessWidget {
  final Cartoon cartoon;

  const CartoonDetailPage({super.key, required this.cartoon});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1b1b1b),
      appBar: AppBar(
        title: Text(
          'การ์ตูน',
          style: GoogleFonts.k2d(fontSize: 18),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            cartoon.imageUrl!.startsWith('http')
                ? Image.network(cartoon.imageUrl!, width: 180)
                : Image.asset(cartoon.imageUrl!, width: 180),
            SizedBox(height: 20),
            Text(
              'ชื่อหนังสือ: ${cartoon.bookname} \nผู้เขียน: ${cartoon.name} \nราคา: ${cartoon.details}',
              style: GoogleFonts.k2d(fontSize: 20, color: Color(0xff5bffc4)),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
