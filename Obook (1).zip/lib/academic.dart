import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class Academic {
  final String? name;
  final String? bookname;
  final String? imageUrl;
  final String? details;

  Academic({this.name, this.bookname, this.imageUrl, this.details});

  factory Academic.fromJson(Map<String, dynamic> json) {
    return Academic(
      name: json['name'],
      bookname: json['bookname'],
      imageUrl: json['image'],
      details: json['details'],
    );
  }
}

class AcademicListPage extends StatefulWidget {
  @override
  _AcademicListPageState createState() => _AcademicListPageState();
}

class _AcademicListPageState extends State<AcademicListPage> {
  List<Academic> academics = [];

  @override
  void initState() {
    super.initState();
    loadJsonData();
  }

  // Load JSON data from assets
  Future<void> loadJsonData() async {
    final String response = await rootBundle.loadString('assets/academic.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      academics = data.map((item) => Academic.fromJson(item)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'วิชาการ',
          style: GoogleFonts.itim(fontSize: 22, color: Color(0xff000000)),
        ),
      ),
      body: academics.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: academics.length,
              itemBuilder: (context, index) {
                final academicItem = academics[index];
                return Card(
                  color: Color(0xff1b1b1b),
                  elevation: 10,
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              AcademicDetailPage(academic: academicItem),
                        ),
                      );
                    },
                    leading: academicItem.imageUrl!.startsWith('http')
                        ? Image.network(academicItem.imageUrl!, width: 100)
                        : Image.asset(academicItem.imageUrl!, width: 100),
                    title: Text(
                      'ผู้เขียน : ${academicItem.name}',
                      style: GoogleFonts.itim(
                          fontSize: 15, color: Color(0xff5bffc4)),
                    ),
                    subtitle: Text(
                      academicItem.bookname ?? '',
                      style: GoogleFonts.itim(fontSize: 20, color: Colors.blue),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class AcademicDetailPage extends StatelessWidget {
  final Academic academic;

  const AcademicDetailPage({super.key, required this.academic});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1b1b1b),
      appBar: AppBar(
        title: Text(
          'วิชาการ',
          style: GoogleFonts.k2d(fontSize: 18),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            academic.imageUrl!.startsWith('http')
                ? Image.network(academic.imageUrl!, width: 180)
                : Image.asset(academic.imageUrl!, width: 180),
            SizedBox(height: 20),
            Text(
              'ชื่อหนังสือ: ${academic.bookname} \nผู้เขียน: ${academic.name} \nราคา: ${academic.details}',
              style: GoogleFonts.k2d(fontSize: 20, color: Color(0xff5bffc4)),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
